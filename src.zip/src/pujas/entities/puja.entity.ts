export class Puja {}
